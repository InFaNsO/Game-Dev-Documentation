---
title: Persona Recommendations — Series Bible
type: series
channel: B Gamer
format: Shorts (≤30s) + occasional long-form
status: test batch 1 scripted
tags: [youtube, shorts, series, recommendations, personas]
---

# Persona Recommendations — Series Bible

A recommendation series built as a conversation between player-personas. The hook: instead of "is this game good" (a verdict, where the biggest channel always wins), it answers **"I loved *this specific thread* in game X — what do I play next?"** — a *match*, which has no single authority and depends on which thread the player is chasing. That's the niche this channel can own.

Recommendations run on games **outside** the genre B Gamer is building ([[Mani Kalpa]]), to prove the channel isn't a stealth ad. Videos that point at the Steam page come later, closer to Next Fest — not here.

## Objective

1. **Build credibility** — become the person turn-based / dark-indie players trust to match them to their next game.
2. **Grow a returning audience** — the persona format + a running obsession turn one-time viewers into regulars.
3. **Set up the later push** — by Next Fest, "the guy who's been dissecting these games made one" lands as a payoff, not a cold pitch.

## The core loop

The anchor game is the one the viewer **just finished** — not the one being recommended. The anchor is the searchable name in the title; the recommendation is the payoff inside.

1. **Cold open call-out** — the viewer persona calls B Gamer out by name and names the game they finished + wants more.
2. **The narrowing question** — B Gamer asks *which thread* hooked them, described through vivid, specific moments from the anchor game (not a flat menu).
3. **The pick** — viewer names the thread; B Gamer recommends a game that nails *that exact thread*.
4. **The riff** — B Gamer goes off on the pick for a few lines.
5. **The punch** — the time-respect obsession lands on the way out, as a reflex.

## Structure & length

- **Total spoken time ~= 30s. This is the ceiling, not the target — shorter and quicker is better.**
- Roughly **55–70 words** of dialogue, no more.
- Shape: cold-open call-out -> narrowing question -> viewer picks thread -> recommendation + short riff -> punch on the exit.
- Predictable frame, fresh payload every episode: the call-out shape stays constant, the game and thread change.

## The cold open (fixed frame)

The viewer persona always calls B Gamer out **by name** and states the finished game + the itch. Same shape, different content each time.

> "Hey B Gamer, I just finished [GAME] and I'm itching for more. Give me something."

## The narrowing question (the craft moment)

This is where B Gamer proves he's actually played the anchor. **Do not list flat options** ("fighting, exploring, movement") — that sounds like a menu. Instead:

- Offer **two vivid, sensory moments** pulled from the *actual* anchor game (a specific boss, mechanic, feeling, item).
- Reference the game **directly** so the viewer thinks "yes — THAT part."
- Let B Gamer's **bias leak** through how he describes them (the option he loves gets the better adjectives). His taste showing is part of the character.

Example (Silksong): *"The white-knuckle boss dance where one more hit ends you? Or the good stuff — stitching together a chain of leaps and never once touching the ground?"*

## B Gamer — the persona

The know-it-all guide who steers the viewer avatar. Confident, opinionated, has taste and shows it.

**The obsession: games that respect your time.** He reveres tight, finishable games and is personally wounded by padding — the 20-hour game wearing an 80-hour trenchcoat, filler checklists, forced slow-walk "cinematic" corridors.

Rules that keep the obsession funny instead of a rant:

1. **Trigger, not soapbox.** It's a reflex reaction to something the viewer just said — snaps in ~3s, not a lecture.
2. **It costs him something.** Funniest when he *can't help himself* and knows it. Self-aware > preachy.
3. **It bends the recommendation, doesn't interrupt it.** The gripe is the *reason* for the pick (he respects your time -> he sends you to the game that respects it too). Never filler.
4. **One punch per short.** One time-waste jab only. Three is a rant.
5. **Rotate the door** (below) so the theme repeats but the joke never does.

## The viewer persona

A *type of player*, not a random character. Pushes back — pokes a hole so B Gamer has to defend, and the defense is the second laugh. Occasionally (every 3rd–4th short) the viewer is **accidentally right / secretly on his side** — this is the release valve so B Gamer isn't always the cranky one.

## The door — how the viewer opens the obsession (rotate every episode)

Repeat the **theme** (respect your time), never the **joke**. Vary the door:

- **Length:** "isn't that game kind of short though?" -> short as a virtue
- **Value:** "only fifteen hours? for full price?" -> time-per-dollar is a scam metric
- **FOMO:** "but the big one has a hundred hours" -> 90 of those are a checklist
- **Completionist:** "don't you want to 100% it?" -> recoils at chasing map icons
- **Trend:** "everyone says the open-world one is the real game" -> suspicious of "everyone"
- **Sequel:** "the new one is way bigger" -> bigger isn't the upgrade they think
- **Backlog:** "I've got forty games I haven't finished" -> a tight game is how you actually finish something
- **Accidental-ally (release valve):** "I finally beat it after three months" / "I skipped most of the side stuff" -> B Gamer either flinches ("three months.") or is secretly proud of them

## Anchor game selection

The anchor is the **net**, the recommendation is the **catch**.

- **Anchor = big AAA/AA with a huge search pool.** YouTube and Instagram push the video to that game's audience; the channel borrows the crowd. An all-indie anchor list was rejected for exactly this reason.
- **Recommendation = the smaller AA/indie game** that nails the chosen thread. It should still have *some* name recognition and search volume so early videos get a spike, not just a click.
- **Ground the thread in real chatter.** Pick the thread from what fans actually praise on Reddit, Steam forums, ResetEra, YouTube comments and the game's wiki/forums, not from guesswork. The two vivid moments in the narrowing question come from that evidence.
- **Anchor must be 3–6 months old minimum.** "I just finished X" about a game nobody has finished destroys credibility.
- **Anchor must sit outside the [[Mani Kalpa]] Venn diagram for now.** Games that overlap the turn-based / dark-mythology audience are banked (below) for the Next Fest push.
- **Anchors are reusable wells.** A big AAA game has several threads (story, combat, world, movement, characters). The same anchor comes back in later rounds with a different thread and a different catch. The only rule is **no repeats inside a single test batch**.
- **GTA VI is excluded**; it has its own series ([[GTA 6 Countdown Calendar]]).

## Banked anchors — Next Fest push only

Overlap the Mani Kalpa audience. Do **not** use as anchors until the Steam-page push.

| Game | Why it is banked |
|---|---|
| Clair Obscur: Expedition 33 | Turn-based + real-time parry, the closest match to Mani Kalpa's combat pillar. Single best future anchor. |
| Slay the Spire 2 | Turn-based strategic combat crowd |
| Hades 2 | Dark mythology, underworld descent |
| Nine Sols | Parry-first combat + Taoist mythology. Flagged trap. |
| Black Myth: Wukong | Mythology audience |
| Baldur's Gate 3 | Turn-based, enormous, save for later |
| Persona 6 | Turn-based, if it has landed by Next Fest |

## Test batches

- **[[Test Batch 1]]** — 5 episodes, one a day, then analyse views / average view duration / swipe-away point and iterate. Anchors: Elden Ring, Spider-Man 2, The Witcher 3, God of War Ragnarök, Cyberpunk 2077. Full scripts, shot lists, mood boards and edit notes in the note and in the interactive [Production Doc](Test%20Batch%201%20-%20Production%20Doc.html).
- **Batch 2 candidates** (fresher search volume): Ghost of Yotei (standoff duel tension → Trek to Yomi), Kingdom Come: Deliverance 2 (consequences that stick → Pentiment or Vampyr).

## Sub-lane: Game Design Breakdown

Keep this as the **smaller** section. One persona (B Gamer, no argument), ~2 min, geeking out on a single system. Same taste, no back-and-forth. Supports credibility without competing with the recommendation loop.

## Pilot (locked reference)

**Anchor:** Silksong · **Thread:** movement/traversal · **Pick:** Neon White · **Door:** backlog

> **VIEWER:** Hey B Gamer, I just finished Silksong and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? The white-knuckle boss dance where one more hit ends you? Or the good stuff — stitching together a chain of leaps and never once touching the ground?
> **VIEWER:** That! The second one. When the movement just *flows* and you don't stop.
> **B GAMER:** Then forget the Metroidvanias — play Neon White. It's a speedrun shooter, every level's a puzzle you solve with your *feet*, and when a route finally clicks you're not walking through it, you're *dancing*. And it's tight, no eighty-hour—
> **VIEWER:** ...and there it is.
> **B GAMER:** You'll *finish* it. When's the last time you finished something?

Why it works: two vivid Silksong moments instead of a flat list; B Gamer's bias leaks (boss = "white-knuckle," movement = "the good stuff"); one punch; the viewer catches him mid-bit; the exit lands on the backlog callback.

## Related

- [[B Gamer]]
- [[GTA 6 Countdown Calendar]]
- [[Mani Kalpa]]
- [[Shorts strategy]]
- [[Test Batch 1]]
