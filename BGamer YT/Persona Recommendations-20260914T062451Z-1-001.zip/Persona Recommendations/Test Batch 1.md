---
title: Persona Recommendations — Test Batch 1
type: batch
series: Persona Recommendations
channel: B Gamer
episodes: 5
status: scripted, not recorded
tags: [youtube, shorts, scripts, personas, test-batch]
---

# Test Batch 1

Five Shorts, one a day, then read the numbers and iterate. Rules and persona live in the [[Series Bible]]. The interactive version of this note, with status tracking, copy buttons and a JSON export for Social Foundry, is [Test Batch 1 - Production Doc](Test%20Batch%201%20-%20Production%20Doc.html).

Every anchor here is a big AAA net chosen for search volume; every recommendation is the smaller catch that nails the thread fans actually talk about. Anchors are reusable in later rounds with different threads; none repeat inside this batch.

## Posting log

| # | Anchor → Rec | Thread | Door | Recorded | Edited | Posted |
|---|---|---|---|---|---|---|
| 1 | Elden Ring → Tunic | Exploration and discovery | FOMO | [ ] | [ ] | [ ] |
| 2 | Spider-Man 2 → Sword of the Sea | Traversal and flow | Value | [ ] | [ ] | [ ] |
| 3 | The Witcher 3 → Banishers: Ghosts of New Eden | Side quests as full stories | Length | [ ] | [ ] | [ ] |
| 4 | God of War Ragnarök → Hellblade II: Senua's Saga | Myth journey and weight | Backlog (accidental ally) | [ ] | [ ] | [ ] |
| 5 | Cyberpunk 2077 → Stray | Atmosphere and scale | Completionist | [ ] | [ ] | [ ] |

After the week: compare views, average view duration and swipe-away point. Drop before the reveal means the narrowing question is slow; drop after the reveal means the punch is weak. Keep the door that held best, retire the one that didn't.

---

## Episode 1: Elden Ring → Tunic

**Thread:** Exploration and discovery · **Door:** FOMO · **Length:** 128 words (target 26–29s)

*Why this thread:* Fans keep saying the magic is finding cool stuff around every corner with no map marker or quest log in sight.

### Script

> **VIEWER:** Hey B Gamer, I just finished Elden Ring and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? The part where you die to the same boss forty times? Or the good stuff, cresting a hill and spotting a whole castle nobody told you was there?
> **VIEWER:** That. The second one. When you just wander and the world keeps hiding things.
> **B GAMER:** Then play Tunic. Little fox, big secret-stuffed world, and it hands you nothing, you piece together your own manual as you go. Every corner's got a thing. And you'll actually *see* all of it, because it's not eighty hours long.
> **VIEWER:** ...you're doing the thing again.
> **B GAMER:** I'm just saying. While everyone else is still stuck halfway through their hundred-hour game, you'll have finished a whole other one. *(punch)*

### Shot by shot

| Time | Frame | On-screen text | Visual | Audio |
|---|---|---|---|---|
| 0.0–2.5 | Viewer frame. Hold on the words "Elden Ring" for a beat. | Hey B Gamer, I just finished ELDEN RING | Elden Ring capture: Tarnished on Torrent galloping across Limgrave at golden hour. Cut in on "Elden Ring". | Viewer VO. Room tone. Tiny UI tick on the title. |
| 2.5–8.0 | B Gamer frame. Two-beat narrowing question. | die to the same boss / forty times → a whole castle nobody told you about | Beat 1: Margit death screen, YOU DIED. Beat 2: slow push-in on Stormveil from the hilltop, no HUD. | B Gamer VO. Beat 1 gets a dull thud; beat 2 gets a soft rising swell, then silence on the reveal. |
| 8.0–11.0 | Viewer frame. Quick, eager. | When you just wander | Elden Ring capture: player turning off the road toward a distant ruin, HUD off. | Viewer VO. Music stays low. |
| 11.0–21.0 | B Gamer frame. Reveal Tunic only at "Then play Tunic". | TUNIC · a fox · a world that hands you nothing | Tunic capture: the fox stepping out of the first cave into the isometric overworld; then a manual page flip; then a hidden path behind a wall. | Reveal sting on the title. Tunic's own chiptune-ish ambience under. Cut the music hard on "eighty hours long". |
| 21.0–23.0 | Viewer frame. Flat, deadpan. | ...you're doing the thing again. | Hold on B Gamer's face frozen mid-sentence for a half second before cutting to the viewer. | Dead silence. Let the awkwardness sit. |
| 23.0–28.5 | B Gamer frame. Punch, straight to camera. | still stuck halfway / you'll have FINISHED a whole other one | Split screen: left, an Elden Ring map with most of it undiscovered; right, Tunic credits rolling. | Music kicks back in on "finished". End on a clean cut, no outro. |

### Mood board

*Gold dusk, ash and moss, then a hand-drawn manual page.*

Palette: Erdtree gold `#d9b45a` · Rot brown `#6b5a3a` · Limgrave moss `#8fa08a` · Ash slate `#2a2f3a` · Manual paper `#f2ead6`

- **Footage to capture:**
  - Elden Ring: Torrent gallop, Margit YOU DIED, Stormveil hilltop, off-road to a ruin (HUD off)
  - Tunic: cave exit into overworld, manual page flip, secret path reveal, credits
- **Type and captions:** Captions in a heavy grotesk, warm off-white. Anchor beats in gold, Tunic beats switch to paper-cream on dark green.
- **Sound:** Low choral pad for Elden Ring beats, hard silence before the Tunic reveal, light synth ambience after. Punch lands on a beat of music returning.

### Edit notes

**Cut**
- Never show the word Tunic before 11s. The reveal is the retention hook.
- Beat 2 of the narrowing question is the money shot: give the Stormveil push-in a full second of no VO.
- Keep the viewer's cutaways rougher than B Gamer's. Persona contrast does half the work.

**Persona contrast**
- Viewer: slightly off-axis, cooler grade, softer light, maybe a headset. Casual.
- B Gamer: dead centre, warmer grade, sharper contrast, straight to lens. Authority.

**Landing the punch**
- The freeze on B Gamer's face before "you're doing the thing again" is the laugh. Do not cut early.
- Deliver "finished a whole other one" slower than everything before it.

**Retention and comments**
- Loop the end frame back into the opener so the auto-replay feels intentional.
- Pin a comment: "What's the last game you actually finished?"

### Publish

- **Title:** Finished Elden Ring? Play this next.
- **First caption:** You'll finish this one.
- **Tags:** #eldenring #tunic #shorts #gamerecommendation
- **Comment bait:** Which castle did you find by accident?

---

## Episode 2: Spider-Man 2 → Sword of the Sea

**Thread:** Traversal and flow · **Door:** Value · **Length:** 124 words (target 26–29s)

*Why this thread:* Fans agree the traversal is the biggest upgrade; one reviewer got halfway through the story before caring about fast travel.

### Script

> **VIEWER:** Hey B Gamer, I just finished Spider-Man 2 and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? The symbiote drama with Peter losing his mind? Or the good stuff, web-wings out, dropping off a tower and never once touching the street?
> **VIEWER:** That. The second one. When the whole city's just a playground and you don't want to stop moving.
> **B GAMER:** Then play Sword of the Sea. You're surfing a sword across dunes and dead oceans, it's pure momentum, no map full of icons, just you and the flow. It's four hours and every one of them counts.
> **VIEWER:** Four hours? For full price?
> **B GAMER:** You paid seventy for Spider-Man and skipped half its side missions. Four hours you'll actually finish beats forty you won't. *(punch)*

### Shot by shot

| Time | Frame | On-screen text | Visual | Audio |
|---|---|---|---|---|
| 0.0–2.5 | Viewer frame. | I just finished SPIDER-MAN 2 | Spider-Man 2 capture: a single long swing down a Manhattan avenue, camera low. | Viewer VO. Wind whoosh under the title. |
| 2.5–8.5 | B Gamer frame. Two beats. | symbiote drama → web-wings out, never touching the street | Beat 1: black-suit Peter close-up, muted. Beat 2: wings deploy off a rooftop, one continuous glide, no cuts. | Beat 1 low, tense. Beat 2 opens up: bright, airy pad, wind rising. |
| 8.5–11.5 | Viewer frame. | the whole city's a playground | Spider-Man 2 capture: chaining swing to zip to glide, fast, no HUD. | Keep the airy pad going. |
| 11.5–22.0 | B Gamer frame. Reveal at "Sword of the Sea". | SWORD OF THE SEA · surfing a sword · pure momentum · four hours | Sword of the Sea capture: cresting a dune, carving down it, water blooming across sand, sea creatures swimming through air. Match the glide motion from beat 2. | Reveal sting. Sword of the Sea ambient under. Cut music on "every one of them counts". |
| 22.0–24.0 | Viewer frame. Sceptical eyebrow. | Four hours? Full price? | Cut to viewer with a quick price tag overlay. | Silence except a tiny cash-register tick on the price. |
| 24.0–29.0 | B Gamer frame. Punch. | seventy for Spider-Man / skipped half the side missions / four you'll FINISH | Overlay: Spider-Man 2 side-mission list with most unchecked, then Sword of the Sea end screen. | Music returns on "finish". Hard out. |

### Mood board

*Red and blue speed, then bleached sand and water light.*

Palette: Suit red `#e0564a` · Suit blue `#2f4fa8` · NYC night `#1a1d2a` · Dune sand `#e8d9b5` · Sea glass `#79c9c2`

- **Footage to capture:**
  - Spider-Man 2: low avenue swing, black-suit close-up, wing deploy glide, swing-zip-glide chain (HUD off)
  - Sword of the Sea: dune crest and carve, water bloom, air-swimming creatures, end screen
- **Type and captions:** Captions bold and slanted for movement beats. Anchor beats in suit red on night blue; Sword beats in sea glass on sand.
- **Sound:** Wind is the through-line. Both halves should share the same wind bed so the match cut feels like one motion.

### Edit notes

**Cut**
- The match cut from the Spider-Man glide to the Sword of the Sea dune carve is the whole episode. Line up the direction of travel.
- Do not show the sword until the reveal. Before that, only sand and motion.
- Keep beat 1 (symbiote) visibly duller so beat 2 pops.

**Persona contrast**
- Same framing rules as episode 1. Keep the viewer's sceptical beat small, an eyebrow, not a face.

**Landing the punch**
- "Four you'll finish beats forty you won't" needs the two numbers on screen, big, stacked.
- The price-tag tick on the viewer's line sets up the value door; keep it under half a second.

**Retention and comments**
- End on the end screen, not on B Gamer, so the last frame is the rec.
- Pin: "How many Spider-Man 2 side missions did you actually do?"

### Publish

- **Title:** Loved swinging in Spider-Man 2? Play this next.
- **First caption:** Four hours. All of them count.
- **Tags:** #spiderman2 #swordofthesea #shorts
- **Comment bait:** Skipped the side missions? Be honest.

---

## Episode 3: The Witcher 3 → Banishers: Ghosts of New Eden

**Thread:** Side quests as full stories · **Door:** Length · **Length:** 122 words (target 26–29s)

*Why this thread:* Fans call the side quests as compelling as the main story; a contract is an entire story: notice board, witnesses, evidence, a monster that may not be the monster.

### Script

> **VIEWER:** Hey B Gamer, I just finished The Witcher 3 and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? Geralt slicing through a nest of drowners? Or the good stuff, taking a contract off a notice board and finding out the monster was never the monster?
> **VIEWER:** That. The second one. When a side quest turns into a whole story and you forget the main quest exists.
> **B GAMER:** Then play Banishers. Two ghost hunters, every haunting is a case, and at the end *you* decide who gets to rest and who doesn't. Every contract's a proper story, none of them are filler.
> **VIEWER:** I mean, Witcher was two hundred hours, so I've got time.
> **B GAMER:** You don't. Nobody does. Play something that respects it. *(punch)*

### Shot by shot

| Time | Frame | On-screen text | Visual | Audio |
|---|---|---|---|---|
| 0.0–2.5 | Viewer frame. | I just finished THE WITCHER 3 | Witcher 3 capture: Geralt riding through Velen mist, HUD off. | Viewer VO. Wind and crows. |
| 2.5–8.5 | B Gamer frame. Two beats. | a nest of drowners → the monster was never the monster | Beat 1: drowner fight in a swamp, fast. Beat 2: notice board close-up, then a slow dialogue shot with a villager, then a hard cut to black. | Beat 1 combat foley. Beat 2: lute drone, then cut to nothing on the black. |
| 8.5–12.0 | Viewer frame. | you forget the main quest exists | Witcher 3 capture: quest log with the main quest greyed out under a stack of side quests. | Lute drone continues. |
| 12.0–22.5 | B Gamer frame. Reveal at "Banishers". | BANISHERS · every haunting is a case · YOU decide | Banishers capture: Antea and Red approaching a haunted farmhouse, a spectral flashback, the spare-or-condemn choice prompt. | Reveal sting. Cold, wet ambience. Cut on "none of them are filler". |
| 22.5–25.0 | Viewer frame. Shrug, half-joking. | two hundred hours / I've got time | Overlay: a playtime counter ticking up past 200h. | Counter tick sound, faster and faster. |
| 25.0–28.5 | B Gamer frame. Punch, quiet. | You don't. Nobody does. | Hold on B Gamer, no overlay, no cutaway. | Kill the counter dead on "You don't." Silence, then a single low note on "respects it". |

### Mood board

*Wet grey mist, dried blood red, then candlelit colonial dark.*

Palette: Dried blood `#b9433f` · Velen mist `#8a8f8c` · Swamp `#3b3a2e` · Candle `#d8a04d` · New Eden night `#1f2228`

- **Footage to capture:**
  - Witcher 3: Velen mist ride, drowner fight, notice board close-up, villager dialogue, quest log with main greyed out
  - Banishers: farmhouse approach, spectral flashback, spare-or-condemn prompt
- **Type and captions:** Captions in a heavy serif-flavoured grotesk for this episode only, to feel like a contract notice. Blood red on mist grey; Banishers beats in candle gold on night.
- **Sound:** Lute drone for Witcher, cold wind and creaking wood for Banishers. The playtime counter is the comic beat; the silence after it is the punch.

### Edit notes

**Cut**
- The hard cut to black after the villager dialogue is the "never the monster" reveal. Do not soften it with a fade.
- Show the choice prompt in Banishers for at least one full second, it is the thread made visible.
- This is the quietest punch in the batch. Resist adding a sting.

**Persona contrast**
- B Gamer drops the energy on the last line. Lower, slower, almost kind. It should feel like he means it.

**Landing the punch**
- "You don't. Nobody does." as two separate cuts if it helps the rhythm.
- No text overlay on the punch. Face only.

**Retention and comments**
- Pin: "Which Witcher 3 contract broke you?"
- Alt title test: "The Witcher 3 ruined side quests for me."

### Publish

- **Title:** Finished The Witcher 3? This has better side quests than most main quests.
- **First caption:** Every contract's a proper story.
- **Tags:** #witcher3 #banishers #shorts
- **Comment bait:** Bloody Baron. Discuss.

---

## Episode 4: God of War Ragnarök → Hellblade II: Senua's Saga

**Thread:** Myth journey and weight · **Door:** Backlog (accidental ally) · **Length:** 118 words (target 26–29s)

*Why this thread:* Fans rave about the weapon feel, but a loud chunk complain it is 70% cut-scenes, forced walking and boat rides with only 30% fighting. That gripe is the door.

### Script

> **VIEWER:** Hey B Gamer, I just finished God of War Ragnarök and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? The axe snapping back into your hand mid-fight? Or the good stuff, that boat ride into the dark, gods dying, a father trying not to lose his son?
> **VIEWER:** That. The second one. The myth, the weight of it. Honestly I'd skip the fights for more of that.
> **B GAMER:** Then play Hellblade II. One woman walking into Norse hell, voices in her head the whole way, and it never lets you breathe. Six hours, no side quests, no—
> **VIEWER:** No forced slow-walk cutscenes?
> **B GAMER:** ...you get it. You actually get it. *(punch)*
> **VIEWER:** Ragnarök had a *lot* of walking.
> **B GAMER:** So much walking.

### Shot by shot

| Time | Frame | On-screen text | Visual | Audio |
|---|---|---|---|---|
| 0.0–2.5 | Viewer frame. | I just finished GOD OF WAR RAGNARÖK | Ragnarök capture: Kratos and Atreus on the boat, snow falling, HUD off. | Viewer VO. Oars in water. |
| 2.5–9.0 | B Gamer frame. Two beats. | the axe snapping back → gods dying, a father, a son | Beat 1: Leviathan Axe recall, one clean hit. Beat 2: slow boat into darkness, then a wordless close-up of Kratos. | Beat 1 axe impact foley. Beat 2 low horn, then breath. |
| 9.0–12.5 | Viewer frame. | the myth, the weight of it | Ragnarök capture: a realm vista, the World Serpent surfacing. | Horn swells. |
| 12.5–21.0 | B Gamer frame. Reveal at "Hellblade II". | HELLBLADE II · voices in her head · six hours · no side quests | Hellblade II capture: Senua on a black-sand beach, a giant looming, a whispered-voices moment with the camera tight on her face. | Reveal sting. Binaural whispers panned hard left and right (headphones note in caption). |
| 21.0–23.0 | Viewer frame. Interrupts, hopeful. | No forced slow-walk cutscenes? | Cut to viewer leaning in. | Whispers stop. Silence. |
| 23.0–26.0 | B Gamer frame. Punch is a face, not a line. | ...you get it. | Hold on B Gamer, stunned, a slow blink. | Silence. Then a tiny, warm chord. |
| 26.0–29.5 | Alternate quickly viewer / B Gamer. | a LOT of walking / So much walking. | Ragnarök capture: Kratos walking a corridor, sped up 4x with a stopwatch overlay. | Comedic stopwatch tick. Out on the last line, no music. |

### Mood board

*Ice blue and ember, then black sand and grey sea.*

Palette: Fimbulwinter ice `#8fb3d9` · Ember `#d1622f` · Norse night `#1c2230` · Black sand `#3a3a3a` · Senua sea `#9aa5a8`

- **Footage to capture:**
  - Ragnarök: boat in snow, axe recall hit, boat into dark, Kratos close-up, World Serpent, corridor walk (for the 4x gag)
  - Hellblade II: black-sand beach, giant reveal, tight face with whispers
- **Type and captions:** Captions cold blue for Ragnarök, near-white on black for Hellblade II. Add a small "headphones" glyph during the whisper beat.
- **Sound:** Binaural whispers are the signature: pan them, and warn in caption. The 4x corridor walk with a stopwatch is the only comedy SFX in the episode.

### Edit notes

**Cut**
- This is the accidental-ally episode. B Gamer does not get to make his speech; the viewer makes it for him. Play his reaction as genuine surprise, not smugness.
- Keep the 4x walking gag under three seconds. It is a button, not a bit.
- Longest script in the batch. If it runs over 30s, cut "Honestly I'd skip the fights for more of that."

**Persona contrast**
- The viewer gets a rare moment of authority. Let their frame be slightly steadier than usual here.

**Landing the punch**
- The punch is the stunned blink. No caption on it.
- "So much walking" delivered flat, exhausted, like a man remembering.

**Retention and comments**
- The stopwatch gag at the end is the rewatch hook.
- Pin: "How long is the boat ride, really?"

### Publish

- **Title:** Ragnarök fans: this one skips the walking.
- **First caption:** Six hours. No side quests. Headphones on.
- **Tags:** #godofwarragnarok #hellblade2 #shorts
- **Comment bait:** Axe or blades? Wrong answers only.

---

## Episode 5: Cyberpunk 2077 → Stray

**Thread:** Atmosphere and scale · **Door:** Completionist · **Length:** 119 words (target 26–29s)

*Why this thread:* Fans describe walking Night City for an hour, ignoring missions, listening to NPCs and never fast-travelling. Feeling small under a megabuilding is the thread.

### Script

> **VIEWER:** Hey B Gamer, I just finished Cyberpunk 2077 and I'm itching for more. Give me something.
> **B GAMER:** More of *what*, though? Johnny Silverhand yelling in your skull? Or the good stuff, standing at the foot of a megabuilding at night, neon everywhere, feeling about three feet tall?
> **VIEWER:** That. The second one. When I'd just walk Night City for an hour and never fast travel.
> **B GAMER:** Then play Stray. You're a cat, alone, in a walled cyber-city that's forgotten the sun. You're not saving the world, you're just *small* in it, and it's gorgeous. Five hours, done.
> **VIEWER:** I'm a completionist though. I need every gig, every question mark.
> **B GAMER:** You never finished those question marks. Play a game where "everything" is actually reachable. *(punch)*

### Shot by shot

| Time | Frame | On-screen text | Visual | Audio |
|---|---|---|---|---|
| 0.0–2.5 | Viewer frame. | I just finished CYBERPUNK 2077 | Cyberpunk capture: V stepping out of Megabuilding H10 onto the street, rain, HUD off. | Viewer VO. Rain, distant traffic, an ad jingle far off. |
| 2.5–9.0 | B Gamer frame. Two beats. | Johnny yelling in your skull → three feet tall under a megabuilding | Beat 1: Johnny glitching into frame, loud. Beat 2: camera tilts up the full height of a megabuilding at night, slow, neon reflections in wet asphalt. | Beat 1 harsh guitar stab. Beat 2 synth pad, low, wide. Let the tilt run. |
| 9.0–12.5 | Viewer frame. | walk Night City for an hour / never fast travel | Cyberpunk capture: first-person walk through a crowded night market, no HUD, no objective. | Pad holds. Add NPC chatter. |
| 12.5–22.0 | B Gamer frame. Reveal at "Stray". | STRAY · a cat · a city that forgot the sun · five hours | Stray capture: the cat dropping into the walled city, neon signs above, a robot looking down at it; then the cat walking a rain-slick alley. | Reveal sting. Stray's warm synth under. Cut on "Five hours, done." |
| 22.0–24.5 | Viewer frame. Defensive. | every gig, every question mark | Overlay: Cyberpunk map crammed with icons, zooming out until it is a solid yellow blob. | A rapid-fire UI tick per icon, becoming a buzz. |
| 24.5–29.0 | B Gamer frame. Punch. | you never finished those / "everything" is actually reachable | Same map, but grey out the icons never touched. Then Stray's 100% trophy pop. | Buzz cuts dead on "never". Trophy chime on "reachable". Out. |

### Mood board

*Acid yellow and cyan on wet black, then warm neon seen from knee height.*

Palette: Night City yellow `#f2e34a` · Cyan glitch `#39c6d6` · Wet asphalt `#161820` · Stray orange `#f08c3c` · Alley violet `#7a5cc7`

- **Footage to capture:**
  - Cyberpunk: Megabuilding exit in rain, Johnny glitch, megabuilding tilt-up, first-person night-market walk, map zoom-out
  - Stray: drop into the city, robot looking down, rain alley walk, trophy pop
- **Type and captions:** Captions in Cyberpunk-style yellow with a one-frame glitch on entry; Stray beats switch to warm orange, no glitch, softer.
- **Sound:** The synth pad is shared across both games. The map-icon buzz is the completionist door made audible; killing it is the punch.

### Edit notes

**Cut**
- Shoot the megabuilding tilt-up as one take. Do not speed it up; the point is scale.
- Match the camera height: Cyberpunk at eye level, Stray at cat level, so the cut itself says "small".
- Stray's title should appear on the robot looking down at the cat, not before.

**Persona contrast**
- Viewer's completionist line should sound a little proud. B Gamer's punch is a factual correction, not a jab.

**Landing the punch**
- Greying out the untouched icons is the whole argument. Make it read in under a second.
- The trophy chime is the only bright sound in the back half.

**Retention and comments**
- Pin: "How many question marks are still on your Night City map?"
- Alt hook test: "You never finished Night City. Admit it."

### Publish

- **Title:** Miss walking Night City? Play this next.
- **First caption:** Five hours. Everything reachable.
- **Tags:** #cyberpunk2077 #stray #shorts
- **Comment bait:** Fast travel: yes or never?

---

## Related

- [[Series Bible]]
- [[B Gamer]]
- [[GTA 6 Countdown Calendar]]
- [[Mani Kalpa]]
